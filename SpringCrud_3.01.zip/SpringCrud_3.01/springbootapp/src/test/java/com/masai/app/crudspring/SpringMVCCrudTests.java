package com.masai.app.crudspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMVCCrudTests {

	@Test
	void contextLoads() {
	}

}
