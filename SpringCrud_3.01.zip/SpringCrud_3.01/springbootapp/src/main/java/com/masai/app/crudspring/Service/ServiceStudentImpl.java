package com.masai.app.crudspring.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.masai.app.crudspring.Entity.Student;
import com.masai.app.crudspring.Reposit.StudentRepository;

@Service
public class ServiceStudentImpl implements Service_Student {

	@Autowired
	StudentRepository repository;

	@Override
	public List<Student> getAllStudents() {
		return repository.findAll();
	}

	@Override
	public Student getStudentById(int id) {
		return repository.findById(id).get();
	}

	@Override
	public Student createStudent(Student student) {
		return repository.save(student);
	}

	@Override
	public Student updateStudent(Student student) {
		return repository.save(student);
	}

}
