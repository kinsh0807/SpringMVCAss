package com.masai.app.crudspring.Service;

import java.util.List;

import com.masai.app.crudspring.Entity.Student;

public interface Service_Student {

    List<Student> getAllStudents();

    Student getStudentById(int id);

    Student createStudent(Student student);

    Student updateStudent(Student student);

}
