package com.masai.app.crudspring.Reposit;

import org.springframework.data.jpa.repository.JpaRepository;

import com.masai.app.crudspring.Entity.Student;

public interface StudentRepository extends JpaRepository<Student,Integer>{

	
}
