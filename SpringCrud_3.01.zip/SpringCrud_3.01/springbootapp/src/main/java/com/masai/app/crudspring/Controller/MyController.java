package com.masai.app.crudspring.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.masai.app.crudspring.Entity.Course;
import com.masai.app.crudspring.Entity.Student;
import com.masai.app.crudspring.Entity.Syllabus;
import com.masai.app.crudspring.Service.Service_Course;
import com.masai.app.crudspring.Service.Service_Student;

import jakarta.validation.Valid;

@RestController
@RequestMapping("myapp/api")
public class MyController {

	@Autowired
	Service_Student service;
	@Autowired
	Service_Course courseservice;

	@GetMapping("/students")
	public List<Student> getAllStudents() {
		return service.getAllStudents();
	}

	@GetMapping("/students/{id}")
	public Student getStudentById(@PathVariable int id) {
		return service.getStudentById(id);
	}

	@PostMapping("/students")
	public Student createStudent(@RequestBody Student student) {
		return service.createStudent(student);
	}

	@PutMapping("/students")
	public Student updateStudent(@RequestBody Student student) {
		return service.updateStudent(student);
	}

	@GetMapping("/courses")
	public List<Course> getAllCourse() {
		return courseservice.getAllCourses();
	}

	@PostMapping("/courses")
	public Course createCourse(@RequestBody Course course) {
		return courseservice.createCourse(course);

	}

	@PutMapping("/courses")
	public Course updateCourse(@RequestBody Course course) {
		return courseservice.updateCourse(course);
	}

	@GetMapping("/course/{id}/syllabus")
	public Syllabus getCourseSyllabus(@PathVariable int id) {
		return courseservice.getCourseSyllabus(id);
	}

	@PostMapping("/course/{id}/syllabus")
	public Syllabus createCourseSyllabus(@Valid @PathVariable int id, @RequestBody Syllabus syllabus) {
		return courseservice.createCourseSyllabus(syllabus);

	}

}
